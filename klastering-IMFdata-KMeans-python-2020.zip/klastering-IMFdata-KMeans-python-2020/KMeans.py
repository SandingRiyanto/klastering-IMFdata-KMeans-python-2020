# library yg digunakan
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from mpl_toolkits import mplot3d
# baca data dari IMFdata.csv
mydata = pd.read_csv('IMFdata.csv')
mydata.head()
myresult = mydata.iloc[:, [0,1,2,3,4]].values

# proses klasterisasi dgn nilai k=4
kmeans4 = KMeans(n_clusters=4)
mykmeans4 = kmeans4.fit_predict(myresult)
kmeans4.cluster_centers_    # centroid klaster x kolom
# membuat objek 3D utk visualisasi data klastering
ax = plt.axes(projection="3d")
ax.scatter3D(myresult[:,2], myresult[:,3], myresult[:,4], c=mykmeans4, cmap='rainbow')
ax.set_xlabel('Gross domestic product')
ax.set_ylabel('Gross national savings')
ax.set_zlabel('Total investment')
plt.show()
# Elbow method; menentukan nilai k yg ideal
WCSS = []
for i in range(1,185):
    kmeans_new = KMeans(n_clusters=i).fit(myresult)
    kmeans_new.fit(myresult)
    WCSS.append(kmeans_new.inertia_)
plt.plot(range(1,185), WCSS)
plt.title('Elbow method')
plt.xlabel('nilai k')
plt.ylabel('tingkat error')
plt.show()
